const express = require('express');
const bodyParser = require('body-parser');
const xlsx = require('xlsx');
const nodemailer = require('nodemailer');
const mysql = require('mysql');
const session = require('express-session');
const mime = require('mime');
const app = express();
let message = '';

// Create a MySQL connection
/*const connection = mysql.createConnection({
  host: 'localhost',
  user: 'python',
  password: 'test@123_',
  database: 'student'
});*/

let pool = mysql.createPool({
  connectionLimit: 100,
  host: 'localhost',
  user: 'python',
  password: 'test@123_',
  database: 'student'
});

app.use(express.static('views', {
  setHeaders: function(res, path) {
    const mimeType = mime.getType(path);
    res.setHeader('Content-Type', mimeType);
  }
}));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(session({
  secret: '@453tbb77ytio_12',
  resave: false,
  saveUninitialized: true
}));

app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.get('/logoutpage', (req, res) => {
  const username = req.session.user.Username;
  res.render('logoutpage', { username, message: message });
});

app.post('/logoutpage', (req, res) => {
  res.render('logoutpage');
});

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  const email = req.body.email;
  const ename = req.body.ename;
  const cname = req.body.cname;
  const contact = req.body.contact;
  const workbook = xlsx.readFile('student.xlsx');
  const worksheet = workbook.Sheets['student-list'];
  const data = xlsx.utils.sheet_to_json(worksheet);
  const user = data.find(u => u.Email === username && u.HKID === password);
  
  /*if (!user) {
	  res.render('login', { error: 'Invalid username or password' });
  }*/
  if (user) {
	pool.getConnection((err, connection) => {
		if (err) throw err;
  // Check the user's status in the MySQL database
		connection.query('SELECT Flag FROM forms WHERE Email = ?', [username], (error, results, fields) => {
		if (error) throw error;

		if (results.length === 0 || results[0].Flag === 0) {
			// User has not completed the form
			req.session.user = { Username: username };
			res.redirect(`/prefilled?ename=${user.EName}&cname=${user.CName}&email=${user.Email}&contact=${user.Phone}`);
		} else {
			// User has already completed the form
			connection.release();
			message = 'You have already completed the form.';
			req.session.user = { Username: username };
			res.redirect('/logoutpage');
			//res.send('You have already completed the form');
		}  
		});
	});
  } else {
	  res.render('login', { error: 'Invalid username or password' });
  };
  /*if (user) {
	req.session.user = { Username: username };
    res.redirect(`/prefilled?ename=${user.EName}&cname=${user.CName}&email=${user.Email}&contact=${user.Phone}`);
  } else {
    res.render('login', { error: 'Invalid username or password' });
  }*/
});

app.get('/prefilled', (req, res) => {
  const username = req.session.user.Username;
  const ename = req.query.ename;
  const cname = req.query.cname;
  const email = req.query.email;
  const contact = req.query.contact;
  res.render('prefilled', { username, ename, cname, email, contact });
});

app.post('/submit', (req, res) => {
  const ename = req.body.ename;
  const cname = req.body.cname;
  const email = req.body.email;
  const contact = req.body.contact;
  const attend = req.body.attend;
  const people = req.body.people;
  
  // Insert the data into the MySQL database
  pool.getConnection((err, connection) => {
  if (err) throw err;
	connection.query('INSERT INTO forms (EName, CName, Email, Phone, Attend, Number, Flag) VALUES (?, ?, ?, ?, ?, ?, 1)', [ename, cname, email, contact, attend, people,], (error, results, fields) => {
    if (error) throw error;
	connection.release();
	});
  });

  const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'ralph.harber67@ethereal.email',
        pass: 'gXJFv5R1FBQv6rUDwR'
    }
  });
 
  const mailOptions = {
    from: email,
    to: 'test@gmail.com',
    subject: 'New message from contact form',
    text: `English Name: ${ename}\nChinese Name: ${cname}\nEmail: ${email}\nContact Number: ${contact}\nI will or will not: ${attend}\nNumber of people to attend: ${people}`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.send('Error');
    } else {
      console.log('Email sent: ' + info.response);
      //res.send('Success');
	  message = 'Your message was send. Thank you.';
	  res.redirect('/logoutpage');
    }
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
    } else {
      res.redirect('/login');
    }
  });

});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});