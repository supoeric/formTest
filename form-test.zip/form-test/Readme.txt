Database: MySQL 8.0
Database name: student
Table name: forms
Database user name: python
Password: test@123_
There is a database backup file in "MySQL-Database-Backup" folder.

We used the following node js module:
express
body-parser
xlsx
nodemailer
mysql
express-session
mime

Email for testing:
https://ethereal.email/
Login: ralph.harber67@ethereal.email
Password: gXJFv5R1FBQv6rUDwR

Run the following command to start the Node.js server:
node server.js

You should be able to access the form at http://localhost:3000





